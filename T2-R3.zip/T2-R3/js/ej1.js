function aleatorio() {
    return Math.floor(Math.random() * 2);
}

function aleatorio100() {
    return Math.floor(Math.random() * 100) + 100;
}