function calcularPotencias() {
    var base = prompt("Escribe un número base");
    var exponente = prompt("Escribe a cuanto deseas exponer");

    document.write(Math.pow(base,exponente));
}